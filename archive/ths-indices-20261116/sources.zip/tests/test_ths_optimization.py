"""Costs and completeness at the ordinary THS maintenance boundaries."""
import asyncio
import copy
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock

import httpx
import pytest

from empire.features.holders import source as holders
from empire.features.index_prices.planning import recent_covers
from empire.features.industries.staging import IndustryStage
from tests.prefetch_source import prefetch_http
from tests.test_all_collector_prefetch import adapter
from tests.test_ths_capital_lifecycle import configured
from tests.test_ths_holders import STOCK, source
from tests.test_ths_index_prices import CODE, ROWS, collector
from tests.test_ths_industries import SNAPSHOT


def test_holder_tree_built_once_with_identical_reports(monkeypatch):
    expected = {k: holders.parse(source(), k, STOCK) for k in holders.KINDS}
    original, calls = holders.Document, []
    def document(body):
        calls.append(1)
        return original(body)
    monkeypatch.setattr(holders, 'Document', document)
    assert holders.parse_all(source().encode('gb18030'), STOCK) == expected
    assert len(calls) == 1


async def test_index_new_day_uses_last_and_date_proof_only():
    c = collector()
    c.query.year_heads.return_value = {
        '2025': dict(source_count=1, complete=True, last_date='2025-12-30'),
        '2026': dict(source_count=1, complete=True, last_date='2026-01-02')}
    c.query.year_dates.return_value = {'2025': ['2025-12-30']}
    await c.execute()
    assert c.http.request.await_count == 1
    assert all(e.raw_payload['mode'] == 'recent' for e in c.ingest.events[1:])


@pytest.mark.parametrize('dates,count,last', [
    (['2025-12-29'], 1, '2025-12-29'),
    (['2025-12-29', '2025-12-30'], 2, '2025-12-30'),
    (['2025-12-30'], 2, '2025-12-30'),
    (['2025-12-30', '2025-12-31'], 1, '2025-12-31'),
])
def test_recent_window_does_not_hide_gap_or_changed_set(dates, count, last):
    snapshot = dict(rows=ROWS[:2], years={'2025': 2}, end='2025-12-31')
    assert not recent_covers(snapshot, '2025', dict(dates=dates, source_count=count, last_date=last, complete=True))


@pytest.mark.parametrize('mode', ['success', 'cancel', 'bad_first'])
async def test_index_parallel_last_preserves_order_and_releases_budget(mode):
    c = collector()
    codes = [CODE, '399412', '399413']
    c.query.catalog.return_value = [dict(code=x, name=x) for x in codes]
    c.query.year_heads.return_value = {
        '2025': dict(source_count=2, complete=True, last_date='2025-12-31'),
        '2026': dict(source_count=1, complete=True, last_date='2026-01-02')}
    original = c.http.request.side_effect
    gate, done = asyncio.Event(), []
    async def request(method, url, **kw):
        if CODE in url:
            await gate.wait()
        response = original(method, url, **kw)
        code = next(x for x in codes if x in url)
        done.append(code)
        return httpx.Response(200, content=b'broken' if mode == 'bad_first' and code == CODE
                              else response.content.replace(CODE.encode(), code.encode()))
    c.http.request.side_effect = request
    c.http.parallelism.return_value = 3
    task = asyncio.create_task(c.execute())
    try:
        async with asyncio.timeout(3):
            while len(done) != 2:
                await asyncio.sleep(0)
        assert not c.ingest.events
        if mode == 'cancel':
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
        else:
            gate.set()
            if mode == 'bad_first':
                with pytest.raises(ValueError):
                    await task
                assert not c.ingest.events
            else:
                await task
                assert [e.raw_payload['code'] for e in c.ingest.events[::3]] == codes
        assert c.http.buffer_budget.used == c.http.buffer_budget.waiting == 0
    finally:
        gate.set()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@pytest.mark.parametrize('family', ['income', 'balance', 'cashflow', 'capital'])
async def test_security_due_selection_reuses_confirmed_and_refreshes_due(family):
    c = configured() if family == 'capital' else adapter(family)[0]
    if family != 'capital':
        c.http = prefetch_http()
    stocks = await c.query.securities()
    keys = [s['unified_code'] if family == 'capital' else s['market'] + ':' + s['code'] for s in stocks]
    c.query.collection_units.return_value = {key: dict(stamp=datetime.now(UTC), count=1, digest='a' * 64) for key in keys}
    c.fetch = AsyncMock(side_effect=AssertionError('unnecessary request'))
    result = await c.execute()
    assert result['phase'] == 'complete' and not c.fetch.called
    assert c.stats['reused_units'] == len(keys)
    c.query.collection_units.return_value[keys[-1]]['stamp'] -= timedelta(days=2)
    with pytest.raises(AssertionError, match='unnecessary request'):
        await c.execute(baseline_revision=await c.checkpoint_revision())
    assert c.fetch.await_count == 1


def test_industry_stage_expiry_scope_and_copy_boundary():
    stage, now = IndustryStage(), datetime.now(UTC)
    catalog = [{k: v for k, v in r.items() if k != 'members'} for r in SNAPSHOT]
    stage.begin(catalog, now)
    stage.put(SNAPSHOT[0])
    stage.get(SNAPSHOT[0]['code']).clear()
    assert stage.get(SNAPSHOT[0]['code']) == SNAPSHOT[0]['members']
    stage.begin(catalog, now + timedelta(minutes=29))
    assert stage.units
    stage.begin(catalog, now + timedelta(minutes=31))
    assert not stage.units
    stage.put(SNAPSHOT[0])
    changed = copy.deepcopy(catalog)
    changed[0]['name'] = '其他行业'
    stage.begin(changed, now + timedelta(minutes=32))
    assert not stage.units


async def test_listing_empty_round_has_no_queue_or_confirmation():
    from empire.features.listings.contract import digest
    from tests.test_ths_listings import STOCKS, collector
    c, state = collector()
    keys = [s['market'] + ':' + s['code'] for s in STOCKS]
    c.query.plan.return_value = (STOCKS, set(keys), dict(scope_hash=digest(keys), units=len(keys),
        refresh_started_at=datetime.now(UTC).isoformat()))
    c.ingest.publish_page = AsyncMock(side_effect=AssertionError('empty queue publication'))
    await c.execute()
    assert state['cursor']['phase'] == 'complete'
    assert not c.fetch.called and not c.confirmation.page_status.called


async def test_industry_failure_reuses_successful_members_without_partial_publish():
    c, reply = adapter('industries')
    failing = True
    requested = []
    async def request(method, url, **kwargs):
        index, response = reply(method, url, kwargs)
        requested.append(index)
        if failing and index == 2:
            return httpx.Response(200, content=b'broken')
        return response
    c.http = prefetch_http(request=AsyncMock(side_effect=request))
    with pytest.raises(ValueError):
        await c.execute()
    assert not c.ingest.events and len(c.staging.units) == 2
    assert not c.confirmation.page_status.called
    failing = False
    await c.execute()
    assert requested == [None, 0, 1, 2, None, 2]
    assert len(c.ingest.events) == 1 and not c.staging.units
    assert c.http.buffer_budget.used == 0
