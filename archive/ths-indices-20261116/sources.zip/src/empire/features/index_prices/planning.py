"""Prove recent updates against the saved date identities, not counts alone."""


def recent_covers(snapshot, year, head):
    if not head or not head.get('complete'):
        return False
    rows = {r[0] for r in snapshot['rows'] if r[0][:4] == year}
    stored = set(head.get('dates', ()))
    if (not rows or not stored or len(stored) != head['source_count']
            or max(stored) != head['last_date'] or head['last_date'] not in rows):
        return False
    # All previously saved dates in the source window must still be present.
    # A replacement/deletion hidden by equal counts cannot pass this check.
    if {d for d in stored if min(rows) <= d <= snapshot['end']} - rows:
        return False
    return (not any(d < min(stored) for d in rows)
            and len(stored | rows) == snapshot['years'][year]
            and max(stored | rows) <= snapshot['end'])
