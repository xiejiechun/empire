"""One active prefetch dimension; never wait on a nested buffer window."""
from contextlib import asynccontextmanager

from empire.features.index_prices.contract import BASE
from empire.plugins.collection.unit_prefetch import BorrowedReservation, UnitRead, prefetch_units

RETAINED_BYTES = 524288


@asynccontextmanager
async def snapshots(collector, codes, first):
    if len(codes) - first == 1:
        async def single():
            yield first, UnitRead(await collector.fetch(codes[first]))
        yield single()
    else:
        async def download(code, *, reservation):
            return await collector.fetch(code, reservation=reservation)
        async with prefetch_units(collector, codes, download, first=first, url=BASE,
                domains=('10jqka.com.cn',), retained_bytes=RETAINED_BYTES, item_name='指数') as reads:
            yield reads


@asynccontextmanager
async def annual_reads(collector, code, years, snapshot, owner):
    if owner is None:
        async def download(year, *, reservation):
            return await collector.fetch(code, year, snapshot, reservation=reservation)
        async with prefetch_units(collector, years, download, url=BASE,
                domains=('10jqka.com.cn',), item_name='年份') as reads:
            yield reads
    else:
        async def sequential():
            for index, year in enumerate(years):
                # The last body is already closed; keep its parsed snapshot
                # allowance while reusing the body's high-water allocation.
                reservation = BorrowedReservation(owner, owner.size - 3 * RETAINED_BYTES)
                read = UnitRead(await collector.fetch(code, year, snapshot, reservation=reservation))
                try:
                    yield index, read
                finally:
                    read.close()
        iterator = sequential()
        try:
            yield iterator
        finally:
            await iterator.aclose()
