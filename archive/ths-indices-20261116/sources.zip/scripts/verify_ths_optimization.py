"""Bounded THS optimization verification using the established private lifecycle."""
import asyncio
import sys

import source_verification as verification
import verify_index_prices
import verify_listings
import verify_ths_capital
import verify_ths_holders
import verify_ths_statements
from catalogue_verification import require_drained, verify_catalogue
from PySide6.QtCore import QCoreApplication
from source_verification import require
from sqlalchemy import text

from empire.core.config import load_config
from empire.features.index_prices.dataset import sql_rows
from empire.features.indices.contract import digest
from empire.plugins.infra.mysql_store import make_engine
from empire.plugins.infra.routing import PROXY_FALLBACK, USE_PROXY


async def securities(manager, selection, args, report):
    args.kinds = ['income', 'balance', 'cashflow']
    for verify in (verify_ths_statements.verify_scope, verify_ths_capital.verify_scope,
                   verify_ths_holders.verify_scope, verify_listings.verify_scope):
        await verify(manager, selection, args, report)
    # Same-period second round must not issue source requests for confirmed
    # finance/capital units. It still uses the official completion boundary.
    for feature in ('income', 'balance', 'cashflow', 'capital'):
        collector = manager.registry.get('collector.ths_' + feature)
        cursor = await collector.execute(baseline_revision=await collector.checkpoint_revision())
        require(cursor['network_costs']['http_attempts'] == 0, '同周期重复下载：' + feature)
        require(cursor['phase'] == 'complete', '维护未完成')
        report['results']['maintenance_' + feature] = dict(pipeline_verified=True,
            acceptance_complete=True, network_costs=cursor['network_costs'],
            reused_units=collector.stats['reused_units'], pending=await require_drained(manager))


async def industries(manager, selection, args, report):
    await verify_catalogue(manager, 'industries', args.proxy_only, report)


def index_catalog(selection, args, report):
    # Copy only the already registered catalogue identities before the private
    # SQL guard starts. Price verification need not recollect 500 member sets.
    engine = make_engine(load_config(args.pool_config)['mysql'])
    try:
        with engine.connect() as conn:
            rows = [dict(conn.execute(text('SELECT index_code,name,source_group FROM stock_index '
                'WHERE index_code=:code'), dict(code=code)).mappings().one())
                for code in verify_index_prices.FIXED_CODES]
    finally:
        engine.dispose()
    selection['catalogue_from_formal_sql'] = rows


async def indices(manager, selection, args, report):
    async def seed_catalogue(manager, kind, proxy_only, report):
        mysql = manager.registry.get('mysql.store')
        def seed():
            with mysql.engine.begin() as conn:
                conn.execute(text('INSERT INTO stock_index(index_code,name,source_group) '
                    'VALUES(:index_code,:name,:source_group)'), selection['catalogue_from_formal_sql'])
        await mysql.control(seed)
    original = verify_index_prices.verify_catalogue
    verify_index_prices.verify_catalogue = seed_catalogue
    try:
        await verify_index_prices.verify_scope(manager, selection, args, report)
    finally:
        verify_index_prices.verify_catalogue = original
    c = manager.registry.get('collector.ths_index_prices')
    cursor = await c.execute(baseline_revision=await c.checkpoint_revision())
    require(cursor['network_costs']['http_attempts'] == len(verify_index_prices.FIXED_CODES),
            '无变化指数维护应只请求每指数last')
    report['results']['index_maintenance'] = dict(pipeline_verified=True, acceptance_complete=True,
        network_costs=cursor['network_costs'], pending=await require_drained(manager))


def index_baseline(selection, args, report):
    index_catalog(selection, args, report)
    engine = make_engine(load_config(args.pool_config)['mysql'])
    args.baseline = {}
    try:
        with engine.connect() as conn, conn.begin():
            for table in ('index_daily_price', 'index_price_year'):
                rows = []
                for code in verify_index_prices.FIXED_CODES:
                    values = [dict(r) for r in conn.execute(text('SELECT * FROM ' + table +
                        ' WHERE index_code=:code LIMIT 15001'), dict(code=code)).mappings()]
                    require(len(values) <= 15000, '已有指数基线超限')
                    rows.extend(values)
                args.baseline[table] = rows
            for head in args.baseline['index_price_year']:
                rows = sql_rows(conn, head['index_code'], head['quote_year'])
                require(head['complete'] and len(rows) == head['row_count'] == head['source_count']
                        and digest(rows) == head['content_hash'], '正式SQL年度基线证明不完整')
    finally:
        engine.dispose()
    report['baseline'] = dict(origin='read_only_formal_SQL', source_history_revalidated=False,
        rows={t: len(rows) for t, rows in args.baseline.items()},
        limitation='完整历史回查两次遇源站502；本轮仅验证相同固定指数近期维护，不替换历史失败证据')


async def maintenance(manager, selection, args, report):
    mysql = manager.registry.get('mysql.store')
    def seed():
        with mysql.engine.begin() as conn:
            tables = {'stock_index': selection['catalogue_from_formal_sql'], **args.baseline}
            for table, rows in tables.items():
                if not rows:
                    continue
                fields = list(rows[0])
                statement = text('INSERT INTO ' + table + '(' + ','.join(fields) + ') VALUES('
                                 + ','.join(':' + f for f in fields) + ')')
                for start in range(0, len(rows), 200):
                    conn.execute(statement, rows[start:start + 200])
    await mysql.control(seed)
    args.baseline.clear()
    await manager.start('collector.ths_index_prices')
    c = manager.registry.get('collector.ths_index_prices')
    q = manager.registry.get('index.prices.query')
    c.selected_codes = list(verify_index_prices.FIXED_CODES)
    original, expected = c.publish, {}
    async def publish(state, cursor, dataset, code, payload, *, observed):
        if dataset == 'index.price.year':
            expected[code, payload['year']] = payload
        return await original(state, cursor, dataset, code, payload, observed=observed)
    c.publish = publish
    try:
        cursor = await c.execute(baseline_revision=await c.checkpoint_revision())
    finally:
        c.publish = original
    def compare():
        with mysql.read_engine.begin() as conn:
            for (code, year), payload in expected.items():
                actual = {r[0]: r for r in sql_rows(conn, code, year)}
                require(all(actual.get(r[0]) == r for r in payload['rows']), '近期来源与归档内容不同')
    await mysql.read(compare)
    for (code, year), payload in expected.items():
        chart = await q.chart_series(code=code, start=f'{year}-01-01', end=f'{year}-12-31')
        actual = {r[0]: r for r in verify_index_prices.canonical(chart['rows'])}
        require(all(actual.get(r[0]) == r for r in payload['rows']), '近期来源与正式查询不同')
    report['results']['maintenance'] = dict(pipeline_verified=True, acceptance_complete=True,
        network_costs=cursor['network_costs'], pending=await require_drained(manager),
        units=[dict(code=k[0], year=k[1], mode=v['mode'], rows=len(v['rows'])) for k, v in expected.items()])
    again = await c.execute(baseline_revision=await c.checkpoint_revision())
    require(again['network_costs']['http_attempts'] - again['network_costs']['retries'] == len(c.selected_codes),
            '第二轮维护重复请求年度')
    report['results']['unchanged'] = dict(pipeline_verified=True, acceptance_complete=True,
        network_costs=again['network_costs'], pending=await require_drained(manager))


def main():
    parser = verification.parser(__doc__)
    parser.add_argument('--scope', choices=('securities', 'industries', 'indices', 'index-maintenance'), required=True)
    args = parser.parse_args()
    _app = QCoreApplication.instance() or QCoreApplication(sys.argv[:1])
    token, fallback = USE_PROXY.set(True), PROXY_FALLBACK.set(not args.proxy_only)
    try:
        if args.scope == 'index-maintenance':
            args.random_count = 0
            passed = asyncio.run(verification.verify(args, maintenance, subject='ths-index-maintenance',
                prepare_scope=index_baseline, non_stock_scope=dict(unit='complete_recent_response',
                    reason='同一固定指数，在已核实正式SQL基线上校验近期完整响应与归档查询',
                    fixed=list(verify_index_prices.FIXED_CODES))))
        elif args.scope == 'indices':
            args.random_count = 0
            passed = asyncio.run(verification.verify(args, indices, subject='ths-index-optimization',
                prepare_scope=index_catalog, non_stock_scope=dict(unit='index_all_available_years',
                    reason='复用已充分固定指数及全部来源年度，目录身份来自正式SQL',
                    fixed=list(verify_index_prices.FIXED_CODES))))
        elif args.scope == 'industries':
            args.random_count = 0
            passed = asyncio.run(verification.verify(args, industries, subject='ths-industry-optimization',
                non_stock_scope=dict(unit='complete_industry_snapshot', reason='完整行业集合不可截断', fixed=[])))
        else:
            passed = asyncio.run(verification.verify(args, securities, subject='ths-securities-optimization',
                fixed_codes=verify_ths_statements.FIXED_CODES, minimum_random=30))
    finally:
        PROXY_FALLBACK.reset(fallback)
        USE_PROXY.reset(token)
    print('PASS' if passed else 'FAIL', flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
